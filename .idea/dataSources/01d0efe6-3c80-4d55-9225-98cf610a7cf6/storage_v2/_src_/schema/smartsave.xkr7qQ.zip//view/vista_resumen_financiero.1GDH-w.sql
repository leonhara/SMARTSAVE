create definer = root@localhost view vista_resumen_financiero as
select `u`.`id`                                                          AS `usuario_id`,
       `u`.`nombre`                                                      AS `nombre`,
       `u`.`apellidos`                                                   AS `apellidos`,
       coalesce(`ingresos`.`total`, 0)                                   AS `total_ingresos`,
       coalesce(`gastos`.`total`, 0)                                     AS `total_gastos`,
       (coalesce(`ingresos`.`total`, 0) - coalesce(`gastos`.`total`, 0)) AS `balance`
from ((`smartsave`.`usuarios` `u` left join (select `smartsave`.`transacciones`.`usuario_id` AS `usuario_id`,
                                                    sum(`smartsave`.`transacciones`.`monto`) AS `total`
                                             from `smartsave`.`transacciones`
                                             where (`smartsave`.`transacciones`.`tipo` = 'Ingreso')
                                             group by `smartsave`.`transacciones`.`usuario_id`) `ingresos`
       on ((`u`.`id` = `ingresos`.`usuario_id`))) left join (select `smartsave`.`transacciones`.`usuario_id` AS `usuario_id`,
                                                                    sum(`smartsave`.`transacciones`.`monto`) AS `total`
                                                             from `smartsave`.`transacciones`
                                                             where (`smartsave`.`transacciones`.`tipo` = 'Gasto')
                                                             group by `smartsave`.`transacciones`.`usuario_id`) `gastos`
      on ((`u`.`id` = `gastos`.`usuario_id`)));

