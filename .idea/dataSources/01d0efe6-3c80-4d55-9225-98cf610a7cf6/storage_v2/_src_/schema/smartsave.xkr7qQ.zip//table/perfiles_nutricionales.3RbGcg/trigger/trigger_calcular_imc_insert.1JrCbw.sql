create definer = root@localhost trigger trigger_calcular_imc_insert
    before insert
    on perfiles_nutricionales
    for each row
BEGIN
    IF NEW.altura > 0 THEN 
        SET NEW.imc = NEW.peso / POWER(NEW.altura / 100, 2);
    ELSE
        SET NEW.imc = 0; 
    END IF;
END;

