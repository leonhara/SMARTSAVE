create
    definer = root@localhost procedure GastosPorCategoria(IN p_usuario_id bigint, IN p_fecha_inicio date, IN p_fecha_fin date)
BEGIN
    SELECT
        categoria,
        SUM(monto) as total_gastado,
        COUNT(*) as numero_transacciones
    FROM transacciones
    WHERE usuario_id = p_usuario_id
    AND tipo = 'Gasto'
    AND fecha BETWEEN p_fecha_inicio AND p_fecha_fin
    GROUP BY categoria
    ORDER BY total_gastado DESC;
END;

