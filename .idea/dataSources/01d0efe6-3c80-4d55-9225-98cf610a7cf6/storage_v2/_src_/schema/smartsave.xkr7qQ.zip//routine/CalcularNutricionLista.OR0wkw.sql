create
    definer = root@localhost procedure CalcularNutricionLista(IN p_lista_id bigint)
BEGIN
    SELECT
        SUM(p.calorias * ic.cantidad) as calorias_totales,
        SUM(p.proteinas * ic.cantidad) as proteinas_totales,
        SUM(p.carbohidratos * ic.cantidad) as carbohidratos_totales,
        SUM(p.grasas * ic.cantidad) as grasas_totales
    FROM items_compra ic
    JOIN productos p ON ic.producto_id = p.id
    WHERE ic.lista_id = p_lista_id;
END;

