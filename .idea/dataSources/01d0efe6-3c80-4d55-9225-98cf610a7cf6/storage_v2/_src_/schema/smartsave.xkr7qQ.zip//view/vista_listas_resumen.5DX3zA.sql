create definer = root@localhost view vista_listas_resumen as
select `lc`.`id`                                                                                            AS `id`,
       `lc`.`nombre`                                                                                        AS `nombre`,
       `lc`.`usuario_id`                                                                                    AS `usuario_id`,
       `lc`.`fecha_creacion`                                                                                AS `fecha_creacion`,
       `lc`.`fecha_planificada`                                                                             AS `fecha_planificada`,
       `lc`.`modalidad_ahorro`                                                                              AS `modalidad_ahorro`,
       `lc`.`presupuesto_maximo`                                                                            AS `presupuesto_maximo`,
       `lc`.`completada`                                                                                    AS `completada`,
       count(`ic`.`id`)                                                                                     AS `total_items`,
       sum((case when (`ic`.`comprado` = true) then 1 else 0 end))                                          AS `items_comprados`,
       round(((sum((case when (`ic`.`comprado` = true) then 1 else 0 end)) * 100.0) / count(`ic`.`id`)),
             2)                                                                                             AS `porcentaje_progreso`,
       sum((`p`.`precio` * `ic`.`cantidad`))                                                                AS `coste_total`
from ((`smartsave`.`listas_compra` `lc` left join `smartsave`.`items_compra` `ic`
       on ((`lc`.`id` = `ic`.`lista_id`))) left join `smartsave`.`productos` `p` on ((`ic`.`producto_id` = `p`.`id`)))
group by `lc`.`id`, `lc`.`nombre`, `lc`.`usuario_id`, `lc`.`fecha_creacion`, `lc`.`fecha_planificada`,
         `lc`.`modalidad_ahorro`, `lc`.`presupuesto_maximo`, `lc`.`completada`;

