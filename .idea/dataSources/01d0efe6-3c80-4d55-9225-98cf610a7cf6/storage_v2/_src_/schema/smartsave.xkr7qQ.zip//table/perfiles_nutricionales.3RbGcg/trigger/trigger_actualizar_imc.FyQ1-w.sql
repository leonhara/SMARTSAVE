create definer = root@localhost trigger trigger_actualizar_imc
    before update
    on perfiles_nutricionales
    for each row
BEGIN
    IF NEW.peso != OLD.peso OR NEW.altura != OLD.altura THEN
        IF NEW.altura > 0 THEN 
            SET NEW.imc = NEW.peso / POWER(NEW.altura / 100, 2);
        ELSE
            SET NEW.imc = 0; 
        END IF;
    END IF;
END;

